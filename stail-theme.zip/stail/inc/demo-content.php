<?php
/**
 * One-time demo content on theme activation, so the prototype is presentable
 * immediately. Runs only once and never touches existing posts of the same type.
 * Prices are placeholders and flagged on the prices page until switched off.
 *
 * @package stail
 */

defined( 'ABSPATH' ) || exit;

add_action( 'after_switch_theme', 'stail_seed_demo_content' );

function stail_seed_demo_content() {
	if ( get_option( 'stail_demo_seeded' ) ) {
		return;
	}
	// after_switch_theme runs on init priority 99, so our post types already exist.
	if ( ! post_type_exists( 'stail_doctor' ) ) {
		return;
	}

	$services = array(
		array( 'Лечение кариеса и терапия', 'Лечим кариес и пульпит под анестезией, восстанавливаем зубы пломбами и вкладками.', 3500 ),
		array( 'Имплантация зубов', 'Восстанавливаем один или все зубы на имплантах. План лечения — после КТ и консультации хирурга.', 35000 ),
		array( 'Протезирование', 'Коронки, виниры и съёмные протезы. Сканируем зубы интраоральным сканером — без слепочной массы.', 18000 ),
		array( 'Исправление прикуса', 'Брекеты и элайнеры для детей и взрослых. Ортодонт смотрит детей с 3 лет.', 45000 ),
		array( 'Хирургия и удаление', 'Удаляем зубы, в том числе зубы мудрости, бережно и с рекомендациями после процедуры.', 2500 ),
		array( 'Гигиена и отбеливание', 'Профессиональная чистка ультразвуком и Air Flow, отбеливание в клинике.', 5500 ),
		array( 'Лечение дёсен', 'Пародонтолог лечит кровоточивость и подвижность зубов, подбирает домашний уход.', 3000 ),
	);
	foreach ( $services as $i => $s ) {
		if ( get_page_by_path( sanitize_title( $s[0] ), OBJECT, 'stail_service' ) ) {
			continue;
		}
		$id = wp_insert_post( array(
			'post_type'    => 'stail_service',
			'post_status'  => 'publish',
			'post_title'   => $s[0],
			'post_excerpt' => $s[1],
			'post_content' => '<p>' . $s[1] . '</p>',
			'menu_order'   => $i,
		) );
		update_post_meta( $id, '_stail_price_from', (string) $s[2] );
	}

	$up      = 'https://stail-s.ru/wp-content/uploads/';
	$doctors = array(
		array( 'Гудкова Анна Александровна', 'Главный врач, стоматолог-терапевт, ортодонт', $up . '2025/08/gudkova.jpg' ),
		array( 'Петухов Иван Ильич', 'Стоматолог-ортопед, гнатолог', $up . '2025/08/petuhov.jpg' ),
		array( 'Петров Игорь Евгеньевич', 'Стоматолог-хирург, имплантолог', $up . '2025/07/petrov-300x300.jpg' ),
		array( 'Эйчис Вероника Юрьевна', 'Стоматолог-терапевт', $up . '2025/07/jejchis-300x300.jpeg' ),
	);
	foreach ( $doctors as $i => $d ) {
		$id = wp_insert_post( array(
			'post_type'   => 'stail_doctor',
			'post_status' => 'publish',
			'post_title'  => $d[0],
			'menu_order'  => $i,
			'post_content'=> '<p>Здесь будет подробная биография врача: образование, курсы повышения квалификации, сертификаты.</p>',
		) );
		update_post_meta( $id, '_stail_specialty', $d[1] );
		update_post_meta( $id, '_stail_photo_url', $d[2] );
	}

	$reviews = array(
		array( 'Татьяна Т.', 'Панически боялась стоматологов, поэтому проблем накопилось много. Пришла по рекомендации и не пожалела: Иван Ильич, Анна и Вероника — профессионалы с чувством юмора, лечиться у них спокойно.', 'Сайт клиники' ),
		array( 'Александр Д.', 'Уже 6 лет всей семьёй ходим к Анне Александровне и Ивану Ильичу. Дочь с 3 лет ходит к ортодонту без уговоров — страха перед стоматологом у неё нет.', 'Сайт клиники' ),
		array( 'Жанна Руднева', 'Удаляла зуб мудрости у Игоря Евгеньевича. Очень переживала, но всё прошло безболезненно и быстро, минут за 20. Дали рекомендации и принесли лёд.', 'Сайт клиники' ),
	);
	foreach ( $reviews as $i => $r ) {
		$id = wp_insert_post( array(
			'post_type'    => 'stail_review',
			'post_status'  => 'publish',
			'post_title'   => $r[0],
			'post_content' => $r[1],
			'menu_order'   => $i,
		) );
		update_post_meta( $id, '_stail_source', $r[2] );
	}

	$prices = array(
		'Консультация и диагностика' => "Первичная консультация любого врача | 0\nПовторная консультация | 1000\nПрицельный снимок | 500\nКТ одной челюсти | 3500\nКТ двух челюстей | 4500",
		'Терапия'                    => "# Лечение кариеса\nЛечение поверхностного кариеса | от 3500\nЛечение глубокого кариеса | от 5500\nЭстетическая реставрация | от 7000\n# Эндодонтия\nЛечение пульпита, 1 канал | от 6500\nЛечение пульпита, 3 канала | от 12500\nПерелечивание канала | от 8000",
		'Гигиена и отбеливание'      => "Профессиональная гигиена полости рта | 5500\nAir Flow | 2500\nОтбеливание в клинике | 22000\nФторирование | 1500",
		'Хирургия'                   => "Удаление зуба простое | 2500\nУдаление зуба сложное | 5500\nУдаление зуба мудрости | от 7500\nСинус-лифтинг | от 30000",
		'Имплантация'                => "Имплантат (Корея) под ключ | от 35000\nИмплантат (Швейцария) под ключ | от 65000\nКостная пластика | от 25000",
		'Ортопедия'                  => "Коронка металлокерамическая | 18000\nКоронка из диоксида циркония | 32000\nКерамическая вкладка | 22000\nВинир керамический | 35000\nСъёмный протез | от 30000",
		'Ортодонтия'                 => "Консультация ортодонта | 0\nМеталлические брекеты (1 челюсть) | от 45000\nКерамические брекеты (1 челюсть) | от 65000\nЭлайнеры «Стайл» | от 120000\nРетейнер | 7000",
	);
	$i = 0;
	foreach ( $prices as $title => $lines ) {
		$id = wp_insert_post( array(
			'post_type'   => 'stail_price',
			'post_status' => 'publish',
			'post_title'  => $title,
			'menu_order'  => $i++,
		) );
		update_post_meta( $id, '_stail_prices', $lines );
	}
	update_option( 'stail_demo_prices', 1 );

	// Photos of the clinic (hotlinked from the current site for the prototype).
	set_theme_mod( 'stail_hero_image', $up . '2025/08/4gabr.jpeg' );
	set_theme_mod( 'stail_gallery', implode( "\n", array(
		$up . '2025/08/11resepsh.jpeg | Ресепшн и диванчик, где можно с удобством подождать',
		$up . '2025/08/7skan.jpeg | Интраоральный сканер вместо слепков',
		$up . '2025/08/6tech.jpeg | Зубной техник работает прямо в клинике',
		$up . '2025/08/5gudk.jpeg | Доктор Гудкова и её пациентка',
	) ) );

	$front = stail_seed_page( 'Главная', 'glavnaya', '' );
	$price = stail_seed_page( 'Цены', 'zeni', '<p>Окончательная стоимость лечения — после осмотра и плана лечения. Первичная консультация бесплатна.</p>', 'page-templates/prices.php' );
	$contacts = stail_seed_page( 'Контакты', 'kontakty', '', 'page-templates/contacts.php' );
	stail_seed_page( 'Политика конфиденциальности', 'politika', '<p>Текст политики конфиденциальности клиники.</p>' );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $front );

	if ( ! has_nav_menu( 'primary' ) ) {
		$menu_id = wp_create_nav_menu( 'Главное меню' );
		if ( ! is_wp_error( $menu_id ) ) {
			$items = array(
				array( 'Услуги', home_url( '/#services' ) ),
				array( 'Врачи', home_url( '/vrachi/' ) ),
				array( 'Цены', get_permalink( $price ) ),
				array( 'Отзывы', home_url( '/#reviews' ) ),
				array( 'Контакты', get_permalink( $contacts ) ),
			);
			foreach ( $items as $item ) {
				wp_update_nav_menu_item( $menu_id, 0, array(
					'menu-item-title'  => $item[0],
					'menu-item-url'    => $item[1],
					'menu-item-type'   => 'custom',
					'menu-item-status' => 'publish',
				) );
			}
			$locations            = get_theme_mod( 'nav_menu_locations', array() );
			$locations['primary'] = $menu_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	}

	flush_rewrite_rules();
	update_option( 'stail_demo_seeded', 1 );
}

function stail_seed_page( $title, $slug, $content, $template = '' ) {
	$existing = get_page_by_path( $slug );
	if ( $existing ) {
		$id = $existing->ID;
	} else {
		$id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => $title,
			'post_name'    => $slug,
			'post_content' => $content,
		) );
	}
	if ( $template ) {
		update_post_meta( $id, '_wp_page_template', $template );
	}
	return $id;
}

/* Admin notice + switch to turn off the "demo prices" banner. */
add_action( 'admin_notices', function () {
	if ( ! get_option( 'stail_demo_prices' ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$url = wp_nonce_url( admin_url( 'admin-post.php?action=stail_prices_live' ), 'stail_prices_live' );
	echo '<div class="notice notice-warning"><p><strong>Прайс-лист содержит демо-цены.</strong> Замените их в разделе «Прайс-лист», затем <a href="' . esc_url( $url ) . '">отметьте цены как актуальные</a> — уберётся пометка на сайте.</p></div>';
} );
add_action( 'admin_post_stail_prices_live', function () {
	if ( current_user_can( 'manage_options' ) && check_admin_referer( 'stail_prices_live' ) ) {
		delete_option( 'stail_demo_prices' );
	}
	wp_safe_redirect( admin_url( 'edit.php?post_type=stail_price' ) );
	exit;
} );
