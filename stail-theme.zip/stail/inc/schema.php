<?php
/**
 * schema.org "Dentist" markup so Yandex/Google understand address, phone,
 * hours and rating.
 *
 * @package stail
 */

defined( 'ABSPATH' ) || exit;

add_action( 'wp_head', function () {
	if ( ! is_front_page() ) {
		return;
	}
	$data = array(
		'@context'     => 'https://schema.org',
		'@type'        => 'Dentist',
		'name'         => stail_opt( 'clinic_name' ),
		'url'          => home_url( '/' ),
		'telephone'    => str_replace( 'tel:', '', stail_tel_href() ),
		'address'      => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => stail_opt( 'address' ),
			'addressLocality' => 'Москва',
			'addressCountry'  => 'RU',
		),
		'foundingDate' => (string) stail_opt( 'founded' ),
		'openingHours' => array( 'Mo-Fr 09:00-21:00', 'Sa-Su 10:00-19:00' ),
	);
	if ( has_custom_logo() ) {
		$data['logo'] = wp_get_attachment_image_url( get_theme_mod( 'custom_logo' ), 'full' );
	}
	if ( stail_opt( 'rating' ) && stail_opt( 'rating_count' ) ) {
		$data['aggregateRating'] = array(
			'@type'       => 'AggregateRating',
			'ratingValue' => stail_opt( 'rating' ),
			'reviewCount' => stail_opt( 'rating_count' ),
		);
	}
	$same = array_filter( array( stail_opt( 'vk_url' ), stail_opt( 'dzen_url' ), stail_opt( 'rutube_url' ), stail_opt( 'map_url' ) ) );
	if ( $same ) {
		$data['sameAs'] = array_values( $same );
	}
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n";
} );
