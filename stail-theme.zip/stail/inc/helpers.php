<?php
/**
 * Small template helpers.
 *
 * @package stail
 */

defined( 'ABSPATH' ) || exit;

/**
 * Read a clinic setting from the Customizer with its default.
 */
function stail_opt( $key ) {
	$defaults = stail_option_defaults();
	return get_theme_mod( 'stail_' . $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
}

/**
 * Phone number reduced to a dialable tel: value, always with a leading "+".
 * Fixes the header/footer mismatch found on the current site.
 */
function stail_tel_href( $phone = null ) {
	$phone  = null === $phone ? stail_opt( 'phone' ) : $phone;
	$digits = preg_replace( '/\D+/', '', (string) $phone );
	if ( '' === $digits ) {
		return '';
	}
	if ( 11 === strlen( $digits ) && '8' === $digits[0] ) {
		$digits = '7' . substr( $digits, 1 );
	}
	return 'tel:+' . $digits;
}

/**
 * Years since the clinic opened.
 */
function stail_years_open() {
	$founded = (int) stail_opt( 'founded' );
	return $founded ? max( 1, (int) wp_date( 'Y' ) - $founded ) : 0;
}

/**
 * Russian plural form: stail_plural( 5, 'год', 'года', 'лет' ).
 */
function stail_plural( $n, $one, $few, $many ) {
	$n   = abs( (int) $n );
	$n10 = $n % 10;
	$n100 = $n % 100;
	if ( 1 === $n10 && 11 !== $n100 ) {
		return $one;
	}
	if ( $n10 >= 2 && $n10 <= 4 && ( $n100 < 10 || $n100 >= 20 ) ) {
		return $few;
	}
	return $many;
}

/**
 * Parse a price list textarea: one item per line, "Название | Цена".
 * A line starting with "#" becomes a sub-heading.
 *
 * @return array<int, array{type:string,name:string,price:string}>
 */
function stail_parse_prices( $raw ) {
	$rows  = array();
	$lines = preg_split( '/\r\n|\r|\n/', (string) $raw );
	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		if ( 0 === strpos( $line, '#' ) ) {
			$rows[] = array( 'type' => 'heading', 'name' => trim( ltrim( $line, '#' ) ), 'price' => '' );
			continue;
		}
		$parts  = array_map( 'trim', explode( '|', $line, 2 ) );
		$rows[] = array(
			'type'  => 'item',
			'name'  => $parts[0],
			'price' => isset( $parts[1] ) ? $parts[1] : '',
		);
	}
	return $rows;
}

/**
 * Format a price string: plain numbers get thousands separators and "₽".
 */
function stail_format_price( $price ) {
	$price = trim( (string) $price );
	if ( preg_match( '/^(от\s*)?([\d\s]+)$/u', $price, $m ) ) {
		$num = (int) preg_replace( '/\s+/', '', $m[2] );
		return trim( $m[1] ) . ( $m[1] ? ' ' : '' ) . number_format( $num, 0, ',', "\u{00A0}" ) . "\u{00A0}₽";
	}
	return $price;
}

/**
 * Two-letter initials for doctors without a photo.
 */
function stail_initials( $name ) {
	$parts = preg_split( '/\s+/u', trim( (string) $name ) );
	$out   = '';
	foreach ( array_slice( $parts, 0, 2 ) as $p ) {
		$out .= mb_substr( $p, 0, 1 );
	}
	return mb_strtoupper( $out );
}

/**
 * Inline SVG icons used across the theme.
 */
function stail_icon( $name ) {
	$icons = array(
		'phone'  => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>',
		'pin'    => '<path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>',
		'clock'  => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
		'chat'   => '<path d="M4 5h16v11H9l-5 4z"/>',
		'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
		'star'   => '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
		'menu'   => '<path d="M4 7h16M4 12h16M4 17h16"/>',
		'close'  => '<path d="M6 6l12 12M18 6 6 18"/>',
		'metro'  => '<path d="M4 18 8.5 6l3.5 7 3.5-7L20 18"/>',
	);
	if ( ! isset( $icons[ $name ] ) ) {
		return '';
	}
	return '<svg class="icon icon-' . esc_attr( $name ) . '" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $icons[ $name ] . '</svg>';
}

/**
 * Page using the "Цены" template, for links from service cards.
 */
function stail_prices_url() {
	$pages = get_pages( array( 'meta_key' => '_wp_page_template', 'meta_value' => 'page-templates/prices.php', 'number' => 1 ) );
	return $pages ? get_permalink( $pages[0] ) : home_url( '/' );
}

/**
 * Transliterate Cyrillic slugs: «Имплантация зубов» → implantatsiya-zubov.
 * Readable Latin URLs instead of %d0%b8%d0%bc… for every new post or page.
 */
function stail_translit_slug( $title, $raw_title = '', $context = 'display' ) {
	if ( 'save' !== $context || ! preg_match( '/[а-яё]/iu', $title ) ) {
		return $title;
	}
	$map = array(
		'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => 'e', 'ж' => 'zh',
		'з' => 'z', 'и' => 'i', 'й' => 'y', 'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n', 'о' => 'o',
		'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't', 'у' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'ts',
		'ч' => 'ch', 'ш' => 'sh', 'щ' => 'sch', 'ъ' => '', 'ы' => 'y', 'ь' => '', 'э' => 'e', 'ю' => 'yu', 'я' => 'ya',
	);
	return strtr( mb_strtolower( $title ), $map );
}
add_filter( 'sanitize_title', 'stail_translit_slug', 9, 3 );

/**
 * Doctor photo: featured image, else photo URL, with initials underneath as fallback.
 */
function stail_doctor_photo( $post_id = null, $size = 'stail-portrait' ) {
	$post_id = $post_id ?: get_the_ID();
	$title   = get_the_title( $post_id );
	$out     = '<span class="photo__initials" aria-hidden="true">' . esc_html( stail_initials( $title ) ) . '</span>';
	if ( has_post_thumbnail( $post_id ) ) {
		$out .= get_the_post_thumbnail( $post_id, $size, array( 'loading' => 'lazy', 'alt' => $title ) );
	} elseif ( $url = get_post_meta( $post_id, '_stail_photo_url', true ) ) {
		$out .= '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( $title ) . '" loading="lazy" onerror="this.remove()">';
	}
	return $out;
}

/**
 * Clinic gallery from the Customizer: "URL | caption" per line.
 */
function stail_gallery() {
	$items = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) stail_opt( 'gallery' ) ) as $line ) {
		$parts = array_map( 'trim', explode( '|', $line, 2 ) );
		if ( ! empty( $parts[0] ) && filter_var( $parts[0], FILTER_VALIDATE_URL ) ) {
			$items[] = array( 'url' => $parts[0], 'caption' => isset( $parts[1] ) ? $parts[1] : '' );
		}
	}
	return $items;
}
