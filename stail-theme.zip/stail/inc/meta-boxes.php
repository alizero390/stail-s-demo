<?php
/**
 * Plain meta boxes — no ACF dependency, so the clinic can't break the site by
 * deactivating a plugin.
 *
 * @package stail
 */

defined( 'ABSPATH' ) || exit;

/**
 * Field definitions per post type: key => [label, type, help].
 */
function stail_meta_fields() {
	return array(
		'stail_doctor'  => array(
			'_stail_specialty'  => array( 'Специализация', 'text', 'Например: стоматолог-ортопед, гнатолог' ),
			'_stail_experience' => array( 'Год начала практики', 'number', 'Стаж посчитается автоматически' ),
			'_stail_education'  => array( 'Образование (кратко)', 'text', '' ),
			'_stail_photo_url'  => array( 'Фото (ссылка)', 'url', 'Если не загружено «Изображение записи». Лучше загрузить фото в медиатеку.' ),
		),
		'stail_service' => array(
			'_stail_price_from' => array( 'Цена «от», ₽', 'text', 'Только число, например 3500' ),
		),
		'stail_review'  => array(
			'_stail_source' => array( 'Источник', 'text', 'Например: Яндекс Карты, ПроДокторов, сайт' ),
			'_stail_doctor' => array( 'Врач (необязательно)', 'text', '' ),
		),
		'stail_price'   => array(
			'_stail_prices' => array( 'Позиции прайса', 'textarea', 'По одной на строку: <code>Название | Цена</code>. Строка с <code>#</code> в начале — подзаголовок. Цена числом станет «3 500 ₽», можно писать «от 3500».' ),
		),
		'stail_booking' => array(
			'_stail_phone'   => array( 'Телефон', 'text', '' ),
			'_stail_reason'  => array( 'Услуга', 'text', '' ),
			'_stail_doctor'  => array( 'Врач', 'text', '' ),
			'_stail_when'    => array( 'Желаемое время', 'text', 'Подтвердите время с пациентом по телефону' ),
			'_stail_comment' => array( 'Комментарий', 'textarea', '' ),
			'_stail_status'  => array( 'Статус (например: перезвонили, записан)', 'text', '' ),
		),
	);
}

add_action( 'add_meta_boxes', function () {
	foreach ( stail_meta_fields() as $type => $fields ) {
		add_meta_box( 'stail_meta', 'Данные', 'stail_render_meta_box', $type, 'normal', 'high', array( 'fields' => $fields ) );
	}
} );

function stail_render_meta_box( $post, $box ) {
	wp_nonce_field( 'stail_meta_save', 'stail_meta_nonce' );
	echo '<table class="form-table" role="presentation">';
	foreach ( $box['args']['fields'] as $key => $field ) {
		list( $label, $type, $help ) = $field;
		$value = get_post_meta( $post->ID, $key, true );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'textarea' === $type ) {
			$rows = '_stail_prices' === $key ? 18 : 4;
			echo '<textarea class="large-text code" rows="' . (int) $rows . '" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( $value ) . '</textarea>';
		} else {
			echo '<input class="regular-text" type="' . esc_attr( $type ) . '" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
		}
		if ( $help ) {
			echo '<p class="description">' . wp_kses( $help, array( 'code' => array() ) ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '</table>';
}

add_action( 'save_post', function ( $post_id, $post ) {
	if ( ! isset( $_POST['stail_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['stail_meta_nonce'] ), 'stail_meta_save' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$all = stail_meta_fields();
	if ( empty( $all[ $post->post_type ] ) ) {
		return;
	}
	foreach ( $all[ $post->post_type ] as $key => $field ) {
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$raw   = wp_unslash( $_POST[ $key ] );
		if ( 'textarea' === $field[1] ) {
			$value = sanitize_textarea_field( $raw );
		} elseif ( 'url' === $field[1] ) {
			$value = esc_url_raw( $raw );
		} else {
			$value = sanitize_text_field( $raw );
		}
		update_post_meta( $post_id, $key, $value );
	}
}, 10, 2 );
