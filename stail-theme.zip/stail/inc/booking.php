<?php
/**
 * Online appointment: a step-by-step widget (service → doctor → day and time →
 * contacts). Each request is saved as a private post, so no lead is lost if mail
 * fails, and e-mailed to the clinic. The administrator confirms the time by phone:
 * without a link to the clinic's scheduling software the widget doesn't know real
 * availability, so it shows every slot within working hours as a preferred time.
 *
 * @package stail
 */

defined( 'ABSPATH' ) || exit;

/**
 * Opening hours parsed from the Customizer text, e.g. "Пн–Пт 9:00–21:00" → [9, 21].
 */
function stail_parse_hours( $text, $fallback ) {
	if ( preg_match_all( '/(\d{1,2})[:.](\d{2})/', (string) $text, $m ) && count( $m[1] ) >= 2 ) {
		return array( (int) $m[1][0] + (int) $m[2][0] / 60, (int) $m[1][1] + (int) $m[2][1] / 60 );
	}
	return $fallback;
}

function stail_booking_form( $context = 'section' ) {
	$status   = isset( $_GET['booking'] ) ? sanitize_key( $_GET['booking'] ) : '';
	$services = get_posts( array( 'post_type' => 'stail_service', 'numberposts' => 30, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	$doctors  = get_posts( array( 'post_type' => 'stail_doctor', 'numberposts' => 30, 'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ) ) );
	$id       = 'booking-' . sanitize_html_class( $context );
	$hours    = array(
		'wd' => stail_parse_hours( stail_opt( 'hours_weekday' ), array( 9, 21 ) ),
		'we' => stail_parse_hours( stail_opt( 'hours_weekend' ), array( 10, 19 ) ),
	);
	$free     = (bool) stail_opt( 'free_consult' );

	ob_start();
	?>
	<form class="booking-form wizard" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="<?php echo esc_attr( $id ); ?>"
		data-hours="<?php echo esc_attr( wp_json_encode( $hours ) ); ?>" data-demo="0" data-demo-busy="0" novalidate>

		<?php if ( 'sent' === $status ) : ?>
			<p class="form-note form-note--ok" role="status">Заявка отправлена. Администратор позвонит вам, чтобы подтвердить время.</p>
		<?php elseif ( 'error' === $status ) : ?>
			<p class="form-note form-note--error" role="alert">Заявка не отправлена: проверьте имя, телефон и согласие на обработку данных — или позвоните нам.</p>
		<?php endif; ?>

		<ol class="wizard__progress" aria-hidden="true">
			<li class="is-active">Услуга</li>
			<li>Врач</li>
			<li>Время</li>
			<li>Контакты</li>
		</ol>

		<input type="hidden" name="action" value="stail_booking">
		<?php wp_nonce_field( 'stail_booking', 'stail_booking_nonce' ); ?>

		<fieldset class="wizard__step is-active" data-step="1">
			<legend class="wizard__title">С чем вы к нам?</legend>
			<div class="choice-list">
				<label class="choice">
					<input type="radio" name="reason" value="Консультация" checked>
					<span class="choice__body"><span class="choice__name">Консультация и осмотр</span><span class="choice__meta"><?php echo $free ? 'Бесплатно' : 'Врач составит план лечения'; ?></span></span>
				</label>
				<?php foreach ( $services as $service ) : ?>
					<?php $from = get_post_meta( $service->ID, '_stail_price_from', true ); ?>
					<label class="choice">
						<input type="radio" name="reason" value="<?php echo esc_attr( $service->post_title ); ?>">
						<span class="choice__body"><span class="choice__name"><?php echo esc_html( $service->post_title ); ?></span><?php if ( '' !== $from ) : ?><span class="choice__meta"><?php echo esc_html( stail_format_price( 'от ' . $from ) ); ?></span><?php endif; ?></span>
					</label>
				<?php endforeach; ?>
				<label class="choice choice--urgent">
					<input type="radio" name="reason" value="Острая боль">
					<span class="choice__body"><span class="choice__name">Острая боль</span><span class="choice__meta">Примем в ближайшее время</span></span>
				</label>
			</div>
		</fieldset>

		<fieldset class="wizard__step" data-step="2">
			<legend class="wizard__title">Выберите врача</legend>
			<div class="choice-list choice-list--doctors">
				<label class="choice choice--doctor">
					<input type="radio" name="doctor" value="" data-name="Любой врач" checked>
					<span class="choice__avatar choice__avatar--any" aria-hidden="true">?</span>
					<span class="choice__body"><span class="choice__name">Любой врач</span><span class="choice__meta">Подберём по вашей задаче</span></span>
				</label>
				<?php foreach ( $doctors as $doctor ) : ?>
					<label class="choice choice--doctor">
						<input type="radio" name="doctor" value="<?php echo (int) $doctor->ID; ?>" data-name="<?php echo esc_attr( $doctor->post_title ); ?>">
						<span class="choice__avatar photo"><?php echo stail_doctor_photo( $doctor->ID, 'thumbnail' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside. ?></span>
						<span class="choice__body"><span class="choice__name"><?php echo esc_html( $doctor->post_title ); ?></span><span class="choice__meta"><?php echo esc_html( get_post_meta( $doctor->ID, '_stail_specialty', true ) ); ?></span></span>
					</label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<fieldset class="wizard__step" data-step="3">
			<legend class="wizard__title">Удобный день и время</legend>
			<div class="days" role="group" aria-label="День"></div>
			<div class="slots" role="group" aria-label="Время"></div>
			<p class="wizard__hint">Администратор позвонит и подтвердит время.</p>
			<input type="hidden" name="date" value="">
			<input type="hidden" name="time" value="">
		</fieldset>

		<fieldset class="wizard__step" data-step="4">
			<legend class="wizard__title">Ваши контакты</legend>
			<dl class="summary"></dl>
			<div class="field">
				<label for="<?php echo esc_attr( $id ); ?>-name">Имя</label>
				<input id="<?php echo esc_attr( $id ); ?>-name" name="name" type="text" autocomplete="name" required maxlength="80">
			</div>
			<div class="field">
				<label for="<?php echo esc_attr( $id ); ?>-phone">Телефон</label>
				<input id="<?php echo esc_attr( $id ); ?>-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required placeholder="+7 (___) ___-__-__" maxlength="24">
			</div>
			<div class="field">
				<label for="<?php echo esc_attr( $id ); ?>-comment">Комментарий <span class="field__opt">— необязательно</span></label>
				<input id="<?php echo esc_attr( $id ); ?>-comment" name="comment" type="text" maxlength="300" placeholder="Например: болит зуб справа сверху">
			</div>
			<div class="field field--trap" aria-hidden="true">
				<label for="<?php echo esc_attr( $id ); ?>-site">Сайт</label>
				<input id="<?php echo esc_attr( $id ); ?>-site" name="site" type="text" tabindex="-1" autocomplete="off">
			</div>
			<label class="consent">
				<input type="checkbox" name="consent" value="1" required>
				<span>Согласен на обработку персональных данных по <a href="<?php echo esc_url( get_privacy_policy_url() ?: home_url( '/politika/' ) ); ?>">политике конфиденциальности</a></span>
			</label>
			<p class="wizard__error" role="alert" hidden></p>
		</fieldset>

		<div class="wizard__nav">
			<button class="btn btn--ghost wizard__back" type="button" hidden>Назад</button>
			<button class="btn btn--primary wizard__next" type="button">Далее</button>
			<button class="btn btn--primary wizard__submit" type="submit">Записаться</button>
		</div>

		<div class="wizard__done" hidden>
			<span class="wizard__check" aria-hidden="true"><svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></span>
			<p class="wizard__done-title">Вы записаны</p>
			<dl class="summary summary--done"></dl>
			<p class="wizard__done-text">Администратор позвонит вам, чтобы подтвердить время. Если планы изменятся — звоните: <a href="<?php echo esc_attr( stail_tel_href() ); ?>"><?php echo esc_html( stail_opt( 'phone' ) ); ?></a></p>
			<p class="wizard__demo-note" hidden>Демо-версия: заявка никуда не отправлена.</p>
			<button class="btn btn--ghost wizard__again" type="button">Записаться ещё раз</button>
		</div>
	</form>
	<?php
	return ob_get_clean();
}

function stail_handle_booking() {
	$back = wp_get_referer() ?: home_url( '/' );
	$back = remove_query_arg( 'booking', $back );

	$field = function ( $key ) {
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	};

	$valid_nonce = isset( $_POST['stail_booking_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['stail_booking_nonce'] ), 'stail_booking' );
	$name        = $field( 'name' );
	$phone       = $field( 'phone' );
	$reason      = $field( 'reason' );
	$comment     = $field( 'comment' );
	$date        = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $field( 'date' ) ) ? $field( 'date' ) : '';
	$time        = preg_match( '/^\d{2}:\d{2}$/', $field( 'time' ) ) ? $field( 'time' ) : '';
	$doctor_id   = absint( $field( 'doctor' ) );
	$doctor      = $doctor_id && 'stail_doctor' === get_post_type( $doctor_id ) ? get_the_title( $doctor_id ) : 'Любой врач';
	$trap        = ! empty( $_POST['site'] );
	$consent     = ! empty( $_POST['consent'] );
	$digits      = preg_replace( '/\D+/', '', $phone );

	if ( $trap ) {
		wp_safe_redirect( add_query_arg( 'booking', 'sent', $back ) . '#booking' );
		exit;
	}
	if ( ! $valid_nonce || '' === $name || strlen( $digits ) < 10 || ! $consent ) {
		wp_safe_redirect( add_query_arg( 'booking', 'error', $back ) . '#booking' );
		exit;
	}

	$when = 'не выбрано';
	if ( $date ) {
		$months = array( 'января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря' );
		$days   = array( 'воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота' );
		$ts     = strtotime( $date . ' 12:00' );
		$when   = (int) gmdate( 'j', $ts ) . ' ' . $months[ (int) gmdate( 'n', $ts ) - 1 ] . ', ' . $days[ (int) gmdate( 'w', $ts ) ] . ( $time ? ', ' . $time : '' );
	}

	$post_id = wp_insert_post( array(
		'post_type'   => 'stail_booking',
		'post_status' => 'private',
		'post_title'  => $name,
	) );
	if ( $post_id && ! is_wp_error( $post_id ) ) {
		update_post_meta( $post_id, '_stail_phone', $phone );
		update_post_meta( $post_id, '_stail_reason', $reason );
		update_post_meta( $post_id, '_stail_doctor', $doctor );
		update_post_meta( $post_id, '_stail_when', $when );
		update_post_meta( $post_id, '_stail_comment', $comment );
		update_post_meta( $post_id, '_stail_consent', current_time( 'mysql' ) );
	}

	$to = stail_opt( 'booking_email' ) ?: get_option( 'admin_email' );
	wp_mail(
		$to,
		'Запись на приём: ' . $name . ( $date ? ', ' . $when : '' ),
		"Имя: {$name}\nТелефон: {$phone}\nУслуга: {$reason}\nВрач: {$doctor}\nЖелаемое время: {$when}\nКомментарий: {$comment}\n\nПозвоните пациенту, чтобы подтвердить время.\nВсе заявки: " . admin_url( 'edit.php?post_type=stail_booking' )
	);

	wp_safe_redirect( add_query_arg( 'booking', 'sent', $back ) . '#booking' );
	exit;
}
add_action( 'admin_post_nopriv_stail_booking', 'stail_handle_booking' );
add_action( 'admin_post_stail_booking', 'stail_handle_booking' );
