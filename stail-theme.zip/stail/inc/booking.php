<?php
/**
 * Booking request form: saved as a private post (so no lead is lost if mail
 * fails) and e-mailed to the clinic.
 *
 * @package stail
 */

defined( 'ABSPATH' ) || exit;

function stail_booking_form( $context = 'section' ) {
	$status   = isset( $_GET['booking'] ) ? sanitize_key( $_GET['booking'] ) : '';
	$services = get_posts( array( 'post_type' => 'stail_service', 'numberposts' => 30, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
	$action   = esc_url( admin_url( 'admin-post.php' ) );
	$id       = 'booking-' . sanitize_html_class( $context );
	ob_start();
	?>
	<form class="booking-form" method="post" action="<?php echo $action; ?>" id="<?php echo esc_attr( $id ); ?>">
		<?php if ( 'sent' === $status ) : ?>
			<p class="form-note form-note--ok" role="status">Заявка отправлена. Администратор перезвонит вам в рабочее время.</p>
		<?php elseif ( 'error' === $status ) : ?>
			<p class="form-note form-note--error" role="alert">Заявка не отправлена: проверьте имя, телефон и согласие на обработку данных — или позвоните нам.</p>
		<?php endif; ?>
		<input type="hidden" name="action" value="stail_booking">
		<?php wp_nonce_field( 'stail_booking', 'stail_booking_nonce' ); ?>
		<div class="field">
			<label for="<?php echo esc_attr( $id ); ?>-name">Имя</label>
			<input id="<?php echo esc_attr( $id ); ?>-name" name="name" type="text" autocomplete="name" required maxlength="80">
		</div>
		<div class="field">
			<label for="<?php echo esc_attr( $id ); ?>-phone">Телефон</label>
			<input id="<?php echo esc_attr( $id ); ?>-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" required placeholder="+7" maxlength="24">
		</div>
		<div class="field">
			<label for="<?php echo esc_attr( $id ); ?>-reason">С чем обращаетесь</label>
			<select id="<?php echo esc_attr( $id ); ?>-reason" name="reason">
				<option value="Бесплатная консультация">Бесплатная консультация</option>
				<?php foreach ( $services as $service ) : ?>
					<option value="<?php echo esc_attr( $service->post_title ); ?>"><?php echo esc_html( $service->post_title ); ?></option>
				<?php endforeach; ?>
				<option value="Острая боль">Острая боль — нужно сегодня</option>
			</select>
		</div>
		<div class="field field--trap" aria-hidden="true">
			<label for="<?php echo esc_attr( $id ); ?>-site">Сайт</label>
			<input id="<?php echo esc_attr( $id ); ?>-site" name="site" type="text" tabindex="-1" autocomplete="off">
		</div>
		<label class="consent">
			<input type="checkbox" name="consent" value="1" required>
			<span>Согласен на обработку персональных данных по <a href="<?php echo esc_url( get_privacy_policy_url() ?: home_url( '/politika/' ) ); ?>">политике конфиденциальности</a></span>
		</label>
		<button class="btn btn--primary btn--block" type="submit">Записаться</button>
		<p class="form-small">Перезвоним в рабочее время: <?php echo esc_html( stail_opt( 'hours_weekday' ) ); ?>, <?php echo esc_html( stail_opt( 'hours_weekend' ) ); ?>.</p>
	</form>
	<?php
	return ob_get_clean();
}

function stail_handle_booking() {
	$back = wp_get_referer() ?: home_url( '/' );
	$back = remove_query_arg( 'booking', $back );

	$valid_nonce = isset( $_POST['stail_booking_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['stail_booking_nonce'] ), 'stail_booking' );
	$name        = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$phone       = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$reason      = isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : '';
	$trap        = ! empty( $_POST['site'] );
	$consent     = ! empty( $_POST['consent'] );
	$digits      = preg_replace( '/\D+/', '', $phone );

	if ( $trap ) {
		wp_safe_redirect( add_query_arg( 'booking', 'sent', $back ) . '#booking' );
		exit;
	}
	if ( ! $valid_nonce || '' === $name || strlen( $digits ) < 10 || ! $consent ) {
		wp_safe_redirect( add_query_arg( 'booking', 'error', $back ) . '#booking' );
		exit;
	}

	$post_id = wp_insert_post( array(
		'post_type'   => 'stail_booking',
		'post_status' => 'private',
		'post_title'  => $name,
	) );
	if ( $post_id && ! is_wp_error( $post_id ) ) {
		update_post_meta( $post_id, '_stail_phone', $phone );
		update_post_meta( $post_id, '_stail_reason', $reason );
		update_post_meta( $post_id, '_stail_consent', current_time( 'mysql' ) );
	}

	$to = stail_opt( 'booking_email' ) ?: get_option( 'admin_email' );
	wp_mail(
		$to,
		'Новая заявка на запись: ' . $name,
		"Имя: {$name}\nТелефон: {$phone}\nВопрос: {$reason}\n\nВсе заявки: " . admin_url( 'edit.php?post_type=stail_booking' )
	);

	wp_safe_redirect( add_query_arg( 'booking', 'sent', $back ) . '#booking' );
	exit;
}
add_action( 'admin_post_nopriv_stail_booking', 'stail_handle_booking' );
add_action( 'admin_post_stail_booking', 'stail_handle_booking' );
