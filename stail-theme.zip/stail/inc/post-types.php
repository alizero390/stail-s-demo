<?php
/**
 * Content types: doctors, services, reviews, price sections, booking requests.
 *
 * @package stail
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	register_post_type( 'stail_doctor', array(
		'labels'        => array(
			'name'          => 'Врачи',
			'singular_name' => 'Врач',
			'add_new_item'  => 'Добавить врача',
			'edit_item'     => 'Редактировать врача',
			'all_items'     => 'Все врачи',
		),
		'public'        => true,
		'has_archive'   => 'vrachi',
		'rewrite'       => array( 'slug' => 'vrach', 'with_front' => false ),
		'menu_icon'     => 'dashicons-id-alt',
		'menu_position' => 20,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
		'show_in_rest'  => true,
	) );

	register_post_type( 'stail_service', array(
		'labels'        => array(
			'name'          => 'Услуги',
			'singular_name' => 'Услуга',
			'add_new_item'  => 'Добавить услугу',
			'edit_item'     => 'Редактировать услугу',
			'all_items'     => 'Все услуги',
		),
		'public'        => true,
		'has_archive'   => false,
		'rewrite'       => array( 'slug' => 'uslugi', 'with_front' => false ),
		'menu_icon'     => 'dashicons-heart',
		'menu_position' => 21,
		'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
		'show_in_rest'  => true,
	) );

	register_post_type( 'stail_review', array(
		'labels'        => array(
			'name'          => 'Отзывы',
			'singular_name' => 'Отзыв',
			'add_new_item'  => 'Добавить отзыв',
			'edit_item'     => 'Редактировать отзыв',
			'all_items'     => 'Все отзывы',
		),
		'public'        => false,
		'show_ui'       => true,
		'menu_icon'     => 'dashicons-format-quote',
		'menu_position' => 22,
		'supports'      => array( 'title', 'editor', 'page-attributes' ),
	) );

	register_post_type( 'stail_price', array(
		'labels'        => array(
			'name'          => 'Прайс-лист',
			'singular_name' => 'Раздел прайса',
			'add_new_item'  => 'Добавить раздел прайса',
			'edit_item'     => 'Редактировать раздел прайса',
			'all_items'     => 'Все разделы',
		),
		'public'        => false,
		'show_ui'       => true,
		'menu_icon'     => 'dashicons-money-alt',
		'menu_position' => 23,
		'supports'      => array( 'title', 'page-attributes' ),
	) );

	register_post_type( 'stail_booking', array(
		'labels'          => array(
			'name'          => 'Заявки на запись',
			'singular_name' => 'Заявка',
			'all_items'     => 'Все заявки',
			'edit_item'     => 'Заявка',
		),
		'public'          => false,
		'show_ui'         => true,
		'menu_icon'       => 'dashicons-calendar-alt',
		'menu_position'   => 24,
		'supports'        => array( 'title' ),
		'capability_type' => 'post',
		'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap'    => true,
	) );
} );

/* Order doctors and services by the "Порядок" field. */
add_action( 'pre_get_posts', function ( WP_Query $q ) {
	if ( is_admin() || ! $q->is_main_query() ) {
		return;
	}
	if ( $q->is_post_type_archive( 'stail_doctor' ) ) {
		$q->set( 'orderby', array( 'menu_order' => 'ASC', 'title' => 'ASC' ) );
		$q->set( 'posts_per_page', -1 );
	}
} );

/* Booking list columns. */
add_filter( 'manage_stail_booking_posts_columns', function ( $cols ) {
	return array(
		'cb'           => $cols['cb'],
		'title'        => 'Имя',
		'stail_phone'  => 'Телефон',
		'stail_reason' => 'Вопрос',
		'date'         => 'Получена',
	);
} );
add_action( 'manage_stail_booking_posts_custom_column', function ( $col, $post_id ) {
	if ( 'stail_phone' === $col ) {
		$phone = get_post_meta( $post_id, '_stail_phone', true );
		echo '<a href="' . esc_attr( stail_tel_href( $phone ) ) . '">' . esc_html( $phone ) . '</a>';
	}
	if ( 'stail_reason' === $col ) {
		echo esc_html( get_post_meta( $post_id, '_stail_reason', true ) );
	}
}, 10, 2 );
