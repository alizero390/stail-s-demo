<?php
/**
 * Clinic details editable in Appearance → Customize → «Клиника».
 *
 * @package stail
 */

defined( 'ABSPATH' ) || exit;

function stail_option_defaults() {
	return array(
		'clinic_name'   => 'Стайл-С',
		'tagline'       => 'Стоматология у метро Отрадное',
		'founded'       => '1991',
		'phone'         => '+7 (495) 777-10-21',
		'address'       => 'Москва, ул. Декабристов, 28, к. 1',
		'metro'         => 'Отрадное',
		'hours_weekday' => 'Пн–Пт 9:00–21:00',
		'hours_weekend' => 'Сб–Вс 10:00–19:00',
		'messenger_url' => '',
		'messenger_name'=> 'Max',
		'map_url'       => 'https://yandex.ru/maps/org/stayl_s/1683692917/',
		'map_embed'     => 'https://yandex.ru/map-widget/v1/?oid=1683692917&z=16',
		'reviews_url'   => 'https://yandex.ru/maps/org/stayl_s/1683692917/reviews/',
		'rating'        => '',
		'rating_count'  => '',
		'free_consult'  => 1,
		'hero_text'     => 'Лечим, протезируем и выравниваем зубы взрослым и детям. Первая консультация у любого врача — бесплатно.',
		'hero_image'    => '',
		'gallery'       => '',
		'legal_name'    => '',
		'inn'           => '',
		'license'       => '',
		'booking_email' => '',
		'vk_url'        => 'https://vk.ru/stail_s',
		'dzen_url'      => 'https://dzen.ru/stail-s.ru',
		'rutube_url'    => 'https://rutube.ru/u/stails/',
	);
}

add_action( 'customize_register', function ( WP_Customize_Manager $wp_customize ) {
	$wp_customize->add_panel( 'stail_clinic', array(
		'title'    => __( 'Клиника', 'stail' ),
		'priority' => 25,
	) );

	$sections = array(
		'stail_contacts' => array(
			'title'  => __( 'Контакты и часы работы', 'stail' ),
			'fields' => array(
				'clinic_name'    => array( 'Название клиники', 'text' ),
				'phone'          => array( 'Телефон', 'text' ),
				'address'        => array( 'Адрес', 'text' ),
				'metro'          => array( 'Станция метро', 'text' ),
				'hours_weekday'  => array( 'Часы работы (будни)', 'text' ),
				'hours_weekend'  => array( 'Часы работы (выходные)', 'text' ),
				'messenger_name' => array( 'Мессенджер: название', 'text' ),
				'messenger_url'  => array( 'Мессенджер: ссылка', 'url' ),
				'booking_email'  => array( 'E-mail для заявок (пусто — e-mail администратора сайта)', 'email' ),
			),
		),
		'stail_hero' => array(
			'title'  => __( 'Первый экран', 'stail' ),
			'fields' => array(
				'tagline'      => array( 'Заголовок (H1)', 'text' ),
				'hero_text'    => array( 'Текст под заголовком', 'textarea' ),
				'founded'      => array( 'Год основания', 'number' ),
				'free_consult' => array( 'Показывать «Первая консультация бесплатно»', 'checkbox' ),
				'hero_image'   => array( 'Фото на первом экране (ссылка)', 'url' ),
				'gallery'      => array( 'Фото клиники: по одному на строку «ссылка | подпись»', 'textarea' ),
			),
		),
		'stail_reviews' => array(
			'title'  => __( 'Карты и рейтинг', 'stail' ),
			'fields' => array(
				'map_url'      => array( 'Ссылка на клинику в Яндекс Картах', 'url' ),
				'map_embed'    => array( 'Ссылка для встроенной карты (map-widget)', 'url' ),
				'reviews_url'  => array( 'Ссылка на отзывы в Яндекс Картах', 'url' ),
				'rating'       => array( 'Рейтинг на Яндекс Картах (например 4.9)', 'text' ),
				'rating_count' => array( 'Количество оценок', 'text' ),
			),
		),
		'stail_legal' => array(
			'title'  => __( 'Юридическая информация', 'stail' ),
			'fields' => array(
				'legal_name' => array( 'Юридическое лицо', 'text' ),
				'inn'        => array( 'ИНН', 'text' ),
				'license'    => array( 'Номер и дата медицинской лицензии', 'text' ),
				'vk_url'     => array( 'ВКонтакте', 'url' ),
				'dzen_url'   => array( 'Дзен', 'url' ),
				'rutube_url' => array( 'Rutube', 'url' ),
			),
		),
	);

	$defaults = stail_option_defaults();
	foreach ( $sections as $section_id => $section ) {
		$wp_customize->add_section( $section_id, array(
			'title' => $section['title'],
			'panel' => 'stail_clinic',
		) );
		foreach ( $section['fields'] as $key => $field ) {
			list( $label, $type ) = $field;
			$sanitize = 'sanitize_text_field';
			if ( 'url' === $type ) {
				$sanitize = 'esc_url_raw';
			} elseif ( 'email' === $type ) {
				$sanitize = 'sanitize_email';
			} elseif ( 'textarea' === $type ) {
				$sanitize = 'sanitize_textarea_field';
			} elseif ( 'checkbox' === $type ) {
				$sanitize = function ( $v ) {
					return $v ? 1 : 0;
				};
			} elseif ( 'number' === $type ) {
				$sanitize = 'absint';
			}
			$wp_customize->add_setting( 'stail_' . $key, array(
				'default'           => isset( $defaults[ $key ] ) ? $defaults[ $key ] : '',
				'sanitize_callback' => $sanitize,
			) );
			$wp_customize->add_control( 'stail_' . $key, array(
				'label'   => $label,
				'section' => $section_id,
				'type'    => $type,
			) );
		}
	}
} );
