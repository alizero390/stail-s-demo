<?php
/**
 * Staff side: branded login page and a dashboard with the clinic's everyday actions.
 *
 * @package stail
 */

defined( 'ABSPATH' ) || exit;

/* Login page in the clinic's colours. */
add_action( 'login_enqueue_scripts', function () {
	$name = esc_html( mb_substr( stail_opt( 'clinic_name' ), 0, 1 ) );
	?>
	<style>
		body.login { background: #f4f6f9; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
		body.login #login { width: 360px; padding-top: 9vh; }
		body.login h1 a {
			background: #14243d; width: 64px; height: 64px; border-radius: 50%;
			display: grid; place-items: center; text-indent: 0; overflow: hidden;
			color: #fff; font-size: 0; text-align: center; box-shadow: inset 0 0 0 3px #14243d, inset 0 0 0 5px #b8925a;
		}
		body.login h1 a::before { content: "<?php echo $name; ?>"; font: 600 34px/64px Georgia, serif; }
		body.login form { border: 0; border-radius: 16px; box-shadow: 0 10px 40px rgba(14,26,43,.08); padding: 28px; }
		body.login label { color: #0e1a2b; font-weight: 600; }
		body.login input[type=text], body.login input[type=password] { border-radius: 10px; border-color: #d6dce5; min-height: 46px; }
		body.login input:focus { border-color: #14243d; box-shadow: 0 0 0 2px rgba(20,36,61,.2); }
		body.login .button-primary { background: #14243d; border-color: #14243d; border-radius: 999px; min-height: 42px; padding: 0 22px; }
		body.login .button-primary:hover { background: #1d3352; border-color: #1d3352; }
		body.login #backtoblog a, body.login #nav a { color: #5e6878; }
		body.login .stail-login-note { text-align: center; color: #5e6878; margin: 0 0 16px; font-size: 14px; }
	</style>
	<?php
} );
add_filter( 'login_headerurl', function () {
	return home_url( '/' );
} );
add_filter( 'login_headertext', function () {
	return stail_opt( 'clinic_name' );
} );
add_filter( 'login_message', function ( $message ) {
	return $message . '<p class="stail-login-note">Вход для сотрудников клиники «' . esc_html( stail_opt( 'clinic_name' ) ) . '»</p>';
} );

/* Dashboard: what the clinic does every day, in one place. */
add_action( 'wp_dashboard_setup', function () {
	wp_add_dashboard_widget( 'stail_clinic', 'Клиника «' . esc_html( stail_opt( 'clinic_name' ) ) . '»', 'stail_dashboard_widget' );

	// Move ours to the top.
	global $wp_meta_boxes;
	$normal = $wp_meta_boxes['dashboard']['normal']['core'];
	$ours   = array( 'stail_clinic' => $normal['stail_clinic'] );
	unset( $normal['stail_clinic'] );
	$wp_meta_boxes['dashboard']['normal']['core'] = array_merge( $ours, $normal );

	// Less noise for clinic staff.
	remove_action( 'welcome_panel', 'wp_welcome_panel' );
	remove_meta_box( 'dashboard_primary', 'dashboard', 'side' );
	remove_meta_box( 'dashboard_quick_press', 'dashboard', 'side' );
	remove_meta_box( 'dashboard_site_health', 'dashboard', 'normal' );
} );

function stail_dashboard_widget() {
	$new = new WP_Query( array(
		'post_type'      => 'stail_booking',
		'post_status'    => 'private',
		'posts_per_page' => 5,
		'date_query'     => array( array( 'after' => '7 days ago' ) ),
	) );
	$links = array(
		array( 'Заявки на запись', admin_url( 'edit.php?post_type=stail_booking' ), 'dashicons-calendar-alt' ),
		array( 'Прайс-лист', admin_url( 'edit.php?post_type=stail_price' ), 'dashicons-money-alt' ),
		array( 'Врачи', admin_url( 'edit.php?post_type=stail_doctor' ), 'dashicons-id-alt' ),
		array( 'Услуги', admin_url( 'edit.php?post_type=stail_service' ), 'dashicons-heart' ),
		array( 'Отзывы', admin_url( 'edit.php?post_type=stail_review' ), 'dashicons-format-quote' ),
		array( 'Контакты и часы работы', admin_url( 'customize.php?autofocus[panel]=stail_clinic' ), 'dashicons-admin-generic' ),
	);
	?>
	<style>
		.stail-dash__grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 10px; margin: 4px 0 18px; }
		.stail-dash__grid a { display: flex; align-items: center; gap: 10px; padding: 14px; border: 1px solid #dcdcde; border-radius: 10px; text-decoration: none; color: #1d2327; font-weight: 600; }
		.stail-dash__grid a:hover { border-color: #14243d; color: #14243d; }
		.stail-dash__grid .dashicons { color: #9a7642; }
		.stail-dash__list { margin: 0; }
		.stail-dash__list li { display: flex; justify-content: space-between; gap: 12px; padding: 8px 0; border-top: 1px solid #f0f0f1; margin: 0; }
	</style>
	<div class="stail-dash__grid">
		<?php foreach ( $links as $l ) : ?>
			<a href="<?php echo esc_url( $l[1] ); ?>"><span class="dashicons <?php echo esc_attr( $l[2] ); ?>"></span><?php echo esc_html( $l[0] ); ?></a>
		<?php endforeach; ?>
	</div>
	<h3>Новые заявки за 7 дней: <?php echo (int) $new->found_posts; ?></h3>
	<?php if ( $new->have_posts() ) : ?>
		<ul class="stail-dash__list">
			<?php foreach ( $new->posts as $b ) : ?>
				<li>
					<a href="<?php echo esc_url( get_edit_post_link( $b ) ); ?>"><?php echo esc_html( $b->post_title ); ?></a>
					<span><?php echo esc_html( get_post_meta( $b->ID, '_stail_phone', true ) ); ?> · <?php echo esc_html( get_the_date( 'd.m H:i', $b ) ); ?></span>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php else : ?>
		<p>Пока новых заявок нет. Заявки с формы на сайте появятся здесь и придут на почту.</p>
	<?php endif; ?>
	<?php
}

/* Count of bookings from the last 7 days next to the menu item. */
add_action( 'admin_menu', function () {
	global $menu;
	$count = ( new WP_Query( array(
		'post_type'      => 'stail_booking',
		'post_status'    => 'private',
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'date_query'     => array( array( 'after' => '7 days ago' ) ),
	) ) )->found_posts;
	if ( ! $count ) {
		return;
	}
	foreach ( $menu as $i => $item ) {
		if ( 'edit.php?post_type=stail_booking' === $item[2] ) {
			$menu[ $i ][0] .= ' <span class="awaiting-mod">' . (int) $count . '</span>';
		}
	}
}, 99 );
