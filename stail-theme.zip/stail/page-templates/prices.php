<?php
/**
 * Template Name: Цены
 *
 * Searchable HTML price list built from «Прайс-лист» sections.
 *
 * @package stail
 */

get_header();

$groups = get_posts( array( 'post_type' => 'stail_price', 'numberposts' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
?>

<section class="page-hero">
	<div class="container">
		<h1 class="page-title"><?php the_title(); ?></h1>
		<?php
		while ( have_posts() ) {
			the_post();
			if ( get_the_content() ) {
				echo '<div class="page-intro">';
				the_content();
				echo '</div>';
			}
		}
		?>
	</div>
</section>

<section class="section section--tight section--tint">
	<div class="container prices">
		<?php if ( get_option( 'stail_demo_prices' ) ) : ?>
			<p class="form-note form-note--warn">Прототип: цены условные и будут заменены на прайс клиники.</p>
		<?php endif; ?>

		<?php if ( $groups ) : ?>
			<div class="prices__tools">
				<label class="price-search">
					<?php echo stail_icon( 'search' ); ?>
					<span class="screen-reader-text">Поиск по прайсу</span>
					<input type="search" id="price-search" placeholder="Найти услугу: коронка, удаление, отбеливание…" autocomplete="off">
				</label>
				<nav class="prices__nav" aria-label="Разделы прайса">
					<?php foreach ( $groups as $group ) : ?>
						<a href="#price-<?php echo (int) $group->ID; ?>"><?php echo esc_html( $group->post_title ); ?></a>
					<?php endforeach; ?>
				</nav>
			</div>

			<p class="prices__empty" id="price-empty" hidden>Ничего не нашлось. Позвоните нам — администратор подскажет стоимость: <a href="<?php echo esc_attr( stail_tel_href() ); ?>"><?php echo esc_html( stail_opt( 'phone' ) ); ?></a></p>

			<?php foreach ( $groups as $group ) : ?>
				<?php $rows = stail_parse_prices( get_post_meta( $group->ID, '_stail_prices', true ) ); ?>
				<details class="price-group" id="price-<?php echo (int) $group->ID; ?>" open>
					<summary class="price-group__title"><h2><?php echo esc_html( $group->post_title ); ?></h2></summary>
					<table class="price-table">
						<tbody>
						<?php foreach ( $rows as $row ) : ?>
							<?php if ( 'heading' === $row['type'] ) : ?>
								<tr class="price-table__sub"><th colspan="2" scope="colgroup"><?php echo esc_html( $row['name'] ); ?></th></tr>
							<?php else : ?>
								<?php $free = in_array( $row['price'], array( '0', 'бесплатно', 'Бесплатно' ), true ); ?>
								<tr class="price-row">
									<td class="price-row__name"><?php echo esc_html( $row['name'] ); ?></td>
									<td class="price-row__price<?php echo $free ? ' is-free' : ''; ?>"><?php echo $free ? 'Бесплатно' : esc_html( stail_format_price( $row['price'] ) ); ?></td>
								</tr>
							<?php endif; ?>
						<?php endforeach; ?>
						</tbody>
					</table>
				</details>
			<?php endforeach; ?>

			<p class="prices__note">Цены указаны в рублях. Итоговая стоимость зависит от клинической ситуации и определяется после осмотра. Для налогового вычета выдаём справку об оплате медицинских услуг.</p>
		<?php else : ?>
			<p>Добавьте разделы в «Прайс-лист» в админке — они появятся здесь.</p>
		<?php endif; ?>
	</div>
</section>

<?php
get_template_part( 'template-parts/cta' );
get_footer();
