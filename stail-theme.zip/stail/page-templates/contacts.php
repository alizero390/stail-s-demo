<?php
/**
 * Template Name: Контакты
 *
 * @package stail
 */

get_header();
?>
<section class="page-hero">
	<div class="container">
		<h1 class="page-title"><?php the_title(); ?></h1>
		<?php
		while ( have_posts() ) {
			the_post();
			if ( get_the_content() ) {
				echo '<div class="page-intro">';
				the_content();
				echo '</div>';
			}
		}
		?>
	</div>
</section>
<?php
get_template_part( 'template-parts/booking-section' );
get_footer();
