<?php
/**
 * Default page.
 *
 * @package stail
 */

get_header();
while ( have_posts() ) :
	the_post();
	?>
	<section class="page-hero">
		<div class="container">
			<h1 class="page-title"><?php the_title(); ?></h1>
		</div>
	</section>
	<section class="section section--tight">
		<div class="container entry">
			<?php the_content(); ?>
		</div>
	</section>
	<?php
endwhile;
get_template_part( 'template-parts/cta' );
get_footer();
