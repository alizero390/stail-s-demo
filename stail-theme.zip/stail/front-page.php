<?php
/**
 * Home page.
 *
 * @package stail
 */

get_header();

$years    = stail_years_open();
$services = get_posts( array( 'post_type' => 'stail_service', 'numberposts' => 12, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
$doctors  = new WP_Query( array( 'post_type' => 'stail_doctor', 'posts_per_page' => 8, 'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ) ) );
$reviews  = get_posts( array( 'post_type' => 'stail_review', 'numberposts' => 3, 'orderby' => 'menu_order', 'order' => 'ASC' ) );
$gallery  = stail_gallery();
$hero_img = stail_opt( 'hero_image' );
?>

<section class="hero" aria-labelledby="hero-title">
	<div class="container hero__grid<?php echo $hero_img ? '' : ' hero__grid--text'; ?>">
		<div class="hero__text">
			<?php if ( stail_opt( 'free_consult' ) ) : ?>
				<p class="badge"><span class="badge__dot" aria-hidden="true"></span>Первая консультация у любого врача — бесплатно</p>
			<?php endif; ?>
			<h1 class="hero__title" id="hero-title"><?php echo esc_html( stail_opt( 'tagline' ) ); ?></h1>
			<p class="hero__lead"><?php echo esc_html( stail_opt( 'hero_text' ) ); ?></p>
			<div class="hero__actions">
				<a class="btn btn--primary" href="#booking">Записаться на консультацию</a>
				<a class="btn btn--ghost" href="<?php echo esc_attr( stail_tel_href() ); ?>"><?php echo stail_icon( 'phone' ); ?><?php echo esc_html( stail_opt( 'phone' ) ); ?></a>
			</div>
			<a class="hero__address" href="<?php echo esc_url( stail_opt( 'map_url' ) ); ?>" target="_blank" rel="noopener"><?php echo stail_icon( 'pin' ); ?> <?php echo esc_html( stail_opt( 'address' ) ); ?>, м. <?php echo esc_html( stail_opt( 'metro' ) ); ?></a>
		</div>

		<div class="hero__media">
			<?php if ( $hero_img ) : ?>
				<img class="hero__photo" src="<?php echo esc_url( $hero_img ); ?>" alt="Врач клиники объясняет пациенту план лечения" fetchpriority="high" onerror="this.parentNode.classList.add('hero__media--nophoto');this.remove()">
			<?php endif; ?>
			<div class="since">
				<span class="since__label">Лечим зубы с</span>
				<span class="since__year"><?php echo esc_html( stail_opt( 'founded' ) ); ?></span>
				<?php if ( $years ) : ?>
					<span class="since__note"><?php echo (int) $years . ' ' . esc_html( stail_plural( $years, 'год', 'года', 'лет' ) ); ?> в Отрадном. Сюда приходят по рекомендации — в том числе со сложными случаями.</span>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>

<section class="facts" aria-label="Почему выбирают клинику">
	<div class="container facts__grid">
		<div class="fact">
			<h2 class="fact__title">Без выходных</h2>
			<p><?php echo esc_html( stail_opt( 'hours_weekday' ) ); ?>, <?php echo esc_html( stail_opt( 'hours_weekend' ) ); ?></p>
		</div>
		<div class="fact">
			<h2 class="fact__title">Сканер вместо слепков</h2>
			<p>Коронки и элайнеры без неприятной слепочной массы</p>
		</div>
		<div class="fact">
			<h2 class="fact__title">Взрослым и детям</h2>
			<p>Все направления: от кариеса до имплантации и элайнеров</p>
		</div>
		<div class="fact">
			<h2 class="fact__title">Налоговый вычет</h2>
			<p>Справка для возврата 13% стоимости лечения</p>
		</div>
	</div>
</section>

<?php if ( $services ) : ?>
<section class="section" id="services" aria-labelledby="services-title">
	<div class="container">
		<div class="section-head">
			<h2 class="section-title" id="services-title">Услуги и цены</h2>
			<a class="link-more" href="<?php echo esc_url( stail_prices_url() ); ?>">Весь прайс-лист</a>
		</div>
		<ul class="services">
			<?php foreach ( $services as $service ) : ?>
				<?php $from = get_post_meta( $service->ID, '_stail_price_from', true ); ?>
				<li class="service">
					<a class="service__link" href="<?php echo esc_url( get_permalink( $service ) ); ?>">
						<span class="service__body">
							<span class="service__title"><?php echo esc_html( $service->post_title ); ?></span>
							<span class="service__text"><?php echo esc_html( get_the_excerpt( $service ) ); ?></span>
						</span>
						<?php if ( '' !== $from ) : ?>
							<span class="service__price"><?php echo esc_html( stail_format_price( 'от ' . $from ) ); ?></span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>
<?php endif; ?>

<?php if ( $gallery ) : ?>
<section class="section section--tint" id="clinic" aria-labelledby="clinic-title">
	<div class="container">
		<div class="section-head">
			<h2 class="section-title" id="clinic-title">Клиника изнутри</h2>
		</div>
		<div class="gallery gallery--<?php echo (int) min( 4, count( $gallery ) ); ?>">
			<?php foreach ( array_slice( $gallery, 0, 4 ) as $item ) : ?>
				<figure class="gallery__item">
					<img src="<?php echo esc_url( $item['url'] ); ?>" alt="<?php echo esc_attr( $item['caption'] ); ?>" loading="lazy" onerror="this.closest('figure').remove()">
					<?php if ( $item['caption'] ) : ?>
						<figcaption><?php echo esc_html( $item['caption'] ); ?></figcaption>
					<?php endif; ?>
				</figure>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( $doctors->have_posts() ) : ?>
<section class="section" id="doctors" aria-labelledby="doctors-title">
	<div class="container">
		<div class="section-head">
			<h2 class="section-title" id="doctors-title">Врачи</h2>
			<a class="link-more" href="<?php echo esc_url( get_post_type_archive_link( 'stail_doctor' ) ); ?>">Все врачи</a>
		</div>
		<div class="doctors">
			<?php
			while ( $doctors->have_posts() ) {
				$doctors->the_post();
				get_template_part( 'template-parts/doctor-card' );
			}
			wp_reset_postdata();
			?>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( $reviews ) : ?>
<section class="section section--tint" id="reviews" aria-labelledby="reviews-title">
	<div class="container">
		<div class="section-head">
			<h2 class="section-title" id="reviews-title">Отзывы пациентов</h2>
			<?php if ( stail_opt( 'reviews_url' ) ) : ?>
				<a class="rating" href="<?php echo esc_url( stail_opt( 'reviews_url' ) ); ?>" target="_blank" rel="noopener">
					<?php if ( stail_opt( 'rating' ) ) : ?>
						<?php echo stail_icon( 'star' ); ?>
						<strong><?php echo esc_html( stail_opt( 'rating' ) ); ?></strong>
						<span>на Яндекс Картах<?php echo stail_opt( 'rating_count' ) ? ', ' . esc_html( stail_opt( 'rating_count' ) ) . ' оценок' : ''; ?></span>
					<?php else : ?>
						<span>Все отзывы на Яндекс Картах</span>
					<?php endif; ?>
				</a>
			<?php endif; ?>
		</div>
		<div class="reviews">
			<?php foreach ( $reviews as $review ) : ?>
				<?php $source = get_post_meta( $review->ID, '_stail_source', true ); ?>
				<figure class="review">
					<blockquote class="review__text"><?php echo wp_kses_post( wpautop( $review->post_content ) ); ?></blockquote>
					<figcaption class="review__author">
						<?php echo esc_html( $review->post_title ); ?>
						<?php if ( $source ) : ?>
							<span class="review__source"><?php echo esc_html( $source ); ?></span>
						<?php endif; ?>
					</figcaption>
				</figure>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<?php
get_template_part( 'template-parts/booking-section' );
get_footer();
