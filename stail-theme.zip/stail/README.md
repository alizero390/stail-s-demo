# Stail Dental — WordPress theme

Theme for a dental clinic, built as a redesign prototype for stail-s.ru.

## Install
1. Appearance → Themes → Add New → Upload Theme → choose `stail-theme.zip` → Activate.
2. On activation the theme creates demo content once: services, doctors, reviews, a price list, the Home / Цены / Контакты pages, and the main menu. Existing posts are not touched.
3. Settings → Permalinks → Save (refreshes URLs).

## Where the clinic edits things
- **Appearance → Customize → Клиника**: phone, address, metro, hours, messenger link, hero text, founding year, Yandex Maps links and rating, legal entity / INN / license.
- **Врачи**: photo (featured image), specialty, year practice started (experience is calculated).
- **Услуги**: text and "from" price shown on the home page.
- **Прайс-лист**: one section per post, one item per line `Название | Цена`, `#` for a sub-heading. After replacing demo prices, use the link in the yellow admin notice to remove the "prototype" label.
- **Отзывы**: author, text, source.
- **Заявки на запись**: every booking request is stored here and e-mailed to the clinic (set the address in Customize → Клиника → Контакты).

## What it fixes vs the current site
- HTML price list with search instead of six JPG images
- Correct `tel:+7…` links everywhere; sticky call/book bar on mobile
- Free consultation and "since 1991" on the first screen; one H1
- Medical disclaimer, legal details and license in the footer
- schema.org `Dentist` markup; Cyrillic slugs auto-transliterated
- Self-hosted fonts, no page builder, no jQuery, map loads on click

## Requirements
WordPress 6.2+, PHP 7.4+. No plugins required (works alongside Yoast SEO).
Fonts: Golos Text and Unbounded, SIL Open Font License.
