<?php
/**
 * Single doctor.
 *
 * @package stail
 */

get_header();
while ( have_posts() ) :
	the_post();
	$specialty  = get_post_meta( get_the_ID(), '_stail_specialty', true );
	$education  = get_post_meta( get_the_ID(), '_stail_education', true );
	$started    = (int) get_post_meta( get_the_ID(), '_stail_experience', true );
	$experience = $started ? max( 1, (int) wp_date( 'Y' ) - $started ) : 0;
	?>
	<section class="section doctor-page">
		<div class="container doctor-page__grid">
			<div class="doctor-page__photo photo">
				<?php echo stail_doctor_photo(); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside. ?>
			</div>
			<div class="doctor-page__body">
				<h1 class="page-title"><?php the_title(); ?></h1>
				<?php if ( $specialty ) : ?>
					<p class="doctor-page__role"><?php echo esc_html( $specialty ); ?></p>
				<?php endif; ?>
				<dl class="doctor-page__facts">
					<?php if ( $experience ) : ?>
						<div><dt>Стаж</dt><dd><?php echo (int) $experience . ' ' . esc_html( stail_plural( $experience, 'год', 'года', 'лет' ) ); ?></dd></div>
					<?php endif; ?>
					<?php if ( $education ) : ?>
						<div><dt>Образование</dt><dd><?php echo esc_html( $education ); ?></dd></div>
					<?php endif; ?>
				</dl>
				<div class="entry"><?php the_content(); ?></div>
				<a class="btn btn--primary" href="<?php echo esc_url( home_url( '/#booking' ) ); ?>">Записаться к врачу</a>
			</div>
		</div>
	</section>
	<?php
endwhile;
get_template_part( 'template-parts/cta' );
get_footer();
