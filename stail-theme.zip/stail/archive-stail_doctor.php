<?php
/**
 * All doctors (/vrachi/).
 *
 * @package stail
 */

get_header();
?>
<section class="page-hero">
	<div class="container">
		<h1 class="page-title">Врачи клиники</h1>
		<p class="page-intro">Запишитесь к конкретному врачу или позвоните — администратор подскажет, кто вам нужен.</p>
	</div>
</section>
<section class="section section--tight">
	<div class="container">
		<div class="doctors doctors--all">
			<?php
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/doctor-card' );
			}
			?>
		</div>
	</div>
</section>
<?php
get_template_part( 'template-parts/cta' );
get_footer();
