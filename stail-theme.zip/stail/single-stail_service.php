<?php
/**
 * Single service page.
 *
 * @package stail
 */

get_header();
while ( have_posts() ) :
	the_post();
	$from = get_post_meta( get_the_ID(), '_stail_price_from', true );
	?>
	<section class="page-hero">
		<div class="container">
			<h1 class="page-title"><?php the_title(); ?></h1>
			<?php if ( '' !== $from ) : ?>
				<p class="page-price"><span><?php echo esc_html( stail_format_price( 'от ' . $from ) ); ?></span> <a href="<?php echo esc_url( stail_prices_url() ); ?>">Подробный прайс</a></p>
			<?php endif; ?>
			<p class="page-actions"><a class="btn btn--primary" href="<?php echo esc_url( add_query_arg( 'service', get_the_title(), home_url( '/' ) ) . '#booking' ); ?>">Записаться на услугу</a></p>
		</div>
	</section>
	<section class="section section--tight">
		<div class="container entry">
			<?php the_content(); ?>
		</div>
	</section>
	<?php
endwhile;
get_template_part( 'template-parts/cta' );
get_footer();
