<?php
/**
 * Blog index and archives.
 *
 * @package stail
 */

get_header();
?>
<section class="page-hero">
	<div class="container">
		<h1 class="page-title"><?php echo is_home() ? esc_html( get_the_title( get_option( 'page_for_posts' ) ) ?: 'Блог' ) : wp_kses_post( get_the_archive_title() ); ?></h1>
	</div>
</section>
<section class="section section--tight">
	<div class="container">
		<?php if ( have_posts() ) : ?>
			<div class="posts">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article <?php post_class( 'post-card' ); ?>>
						<a class="post-card__link" href="<?php the_permalink(); ?>">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy' ) ); ?>
							<?php endif; ?>
							<h2 class="post-card__title"><?php the_title(); ?></h2>
						</a>
						<p><?php echo esc_html( get_the_excerpt() ); ?></p>
					</article>
				<?php endwhile; ?>
			</div>
			<?php the_posts_pagination( array( 'prev_text' => 'Назад', 'next_text' => 'Дальше' ) ); ?>
		<?php else : ?>
			<p>Здесь пока ничего нет.</p>
		<?php endif; ?>
	</div>
</section>
<?php
get_footer();
