<?php
/**
 * Site footer with the legally required details for a medical clinic.
 *
 * @package stail
 */
?>
</main>

<footer class="site-footer">
	<div class="container site-footer__grid">
		<div class="site-footer__col">
			<p class="site-footer__name"><?php echo esc_html( stail_opt( 'clinic_name' ) ); ?></p>
			<p>Стоматологическая клиника в Москве с <?php echo esc_html( stail_opt( 'founded' ) ); ?> года</p>
			<?php
			$socials = array(
				'ВКонтакте' => stail_opt( 'vk_url' ),
				'Дзен'      => stail_opt( 'dzen_url' ),
				'Rutube'    => stail_opt( 'rutube_url' ),
			);
			$socials = array_filter( $socials );
			if ( $socials ) :
				?>
				<ul class="site-footer__social">
					<?php foreach ( $socials as $label => $url ) : ?>
						<li><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $label ); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<div class="site-footer__col">
			<p class="site-footer__label">Контакты</p>
			<p><a class="site-footer__phone" href="<?php echo esc_attr( stail_tel_href() ); ?>"><?php echo esc_html( stail_opt( 'phone' ) ); ?></a></p>
			<p><?php echo esc_html( stail_opt( 'address' ) ); ?></p>
			<p><?php echo esc_html( stail_opt( 'hours_weekday' ) ); ?><br><?php echo esc_html( stail_opt( 'hours_weekend' ) ); ?></p>
		</div>

		<div class="site-footer__col">
			<p class="site-footer__label">Пациентам</p>
			<?php
			if ( has_nav_menu( 'footer' ) ) {
				wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'menu_class' => 'site-footer__menu', 'depth' => 1 ) );
			} else {
				wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'site-footer__menu', 'depth' => 1, 'fallback_cb' => false ) );
			}
			?>
		</div>
	</div>

	<div class="container site-footer__legal">
		<p class="site-footer__warning">Имеются противопоказания. Необходима консультация специалиста.</p>
		<p>
			<?php
			$legal = array_filter( array(
				stail_opt( 'legal_name' ),
				stail_opt( 'inn' ) ? 'ИНН ' . stail_opt( 'inn' ) : '',
				stail_opt( 'license' ) ? 'Лицензия ' . stail_opt( 'license' ) : '',
			) );
			echo esc_html( $legal ? implode( ', ', $legal ) : 'Юридическое лицо, ИНН и номер медицинской лицензии — заполните в «Внешний вид → Настроить → Клиника».' );
			?>
		</p>
		<p>
			© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( stail_opt( 'clinic_name' ) ); ?>.
			<a href="<?php echo esc_url( get_privacy_policy_url() ?: home_url( '/politika/' ) ); ?>">Политика конфиденциальности</a>.
			Информация на сайте не является публичной офертой.
		</p>
		<p><a class="site-footer__login" href="<?php echo esc_url( wp_login_url() ); ?>" rel="nofollow">Вход для сотрудников</a></p>
	</div>
</footer>

<div class="mobile-bar" role="region" aria-label="Быстрая связь">
	<a class="mobile-bar__call" href="<?php echo esc_attr( stail_tel_href() ); ?>"><?php echo stail_icon( 'phone' ); ?> Позвонить</a>
	<a class="mobile-bar__book" href="<?php echo esc_url( home_url( '/#booking' ) ); ?>">Записаться</a>
</div>

<?php wp_footer(); ?>
</body>
</html>
