<?php
/**
 * Doctor card. Expects to be inside the loop / setup_postdata.
 *
 * @package stail
 */

$specialty  = get_post_meta( get_the_ID(), '_stail_specialty', true );
$started    = (int) get_post_meta( get_the_ID(), '_stail_experience', true );
$experience = $started ? max( 1, (int) wp_date( 'Y' ) - $started ) : 0;
?>
<article class="doctor">
	<a class="doctor__link" href="<?php the_permalink(); ?>">
		<div class="doctor__photo photo">
			<?php echo stail_doctor_photo(); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside. ?>
		</div>
		<h3 class="doctor__name"><?php the_title(); ?></h3>
	</a>
	<?php if ( $specialty ) : ?>
		<p class="doctor__role"><?php echo esc_html( $specialty ); ?></p>
	<?php endif; ?>
	<?php if ( $experience ) : ?>
		<p class="doctor__exp">Стаж <?php echo (int) $experience . ' ' . esc_html( stail_plural( $experience, 'год', 'года', 'лет' ) ); ?></p>
	<?php endif; ?>
</article>
