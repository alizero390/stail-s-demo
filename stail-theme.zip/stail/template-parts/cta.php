<?php
/**
 * Call-to-action band for inner pages (no address or map here — those live on
 * the home and contacts pages).
 *
 * @package stail
 */
?>
<section class="cta-band">
	<div class="container cta-band__inner">
		<div>
			<p class="cta-band__title">Запишитесь на консультацию</p>
			<p class="cta-band__text"><?php echo stail_opt( 'free_consult' ) ? 'Первый приём у любого врача — бесплатно. ' : ''; ?>Перезвоним и подберём удобное время.</p>
		</div>
		<div class="cta-band__actions">
			<a class="btn btn--light-solid" href="<?php echo esc_url( home_url( '/#booking' ) ); ?>">Записаться</a>
			<a class="btn btn--light" href="<?php echo esc_attr( stail_tel_href() ); ?>"><?php echo esc_html( stail_opt( 'phone' ) ); ?></a>
		</div>
	</div>
</section>
