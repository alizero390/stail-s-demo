<?php
/**
 * Booking form + contacts + map. Reused on the front page and contacts page.
 *
 * @package stail
 */
?>
<section class="section booking" id="booking" aria-labelledby="booking-title">
	<div class="container booking__grid">
		<div class="booking__intro">
			<h2 class="section-title" id="booking-title">Запишитесь на приём</h2>
			<p class="section-lead">Онлайн за минуту: выберите услугу, врача и удобное время — администратор подтвердит запись звонком.<?php if ( stail_opt( 'free_consult' ) ) : ?> Первая консультация бесплатно.<?php endif; ?></p>

			<ul class="contact-list">
				<li>
					<?php echo stail_icon( 'phone' ); ?>
					<a href="<?php echo esc_attr( stail_tel_href() ); ?>"><?php echo esc_html( stail_opt( 'phone' ) ); ?></a>
				</li>
				<?php if ( stail_opt( 'messenger_url' ) ) : ?>
					<li>
						<?php echo stail_icon( 'chat' ); ?>
						<a href="<?php echo esc_url( stail_opt( 'messenger_url' ) ); ?>" target="_blank" rel="noopener">Написать в <?php echo esc_html( stail_opt( 'messenger_name' ) ); ?></a>
					</li>
				<?php endif; ?>
				<li>
					<?php echo stail_icon( 'pin' ); ?>
					<a href="<?php echo esc_url( stail_opt( 'map_url' ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( stail_opt( 'address' ) ); ?>, м. <?php echo esc_html( stail_opt( 'metro' ) ); ?></a>
				</li>
				<li>
					<?php echo stail_icon( 'clock' ); ?>
					<span><?php echo esc_html( stail_opt( 'hours_weekday' ) ); ?>, <?php echo esc_html( stail_opt( 'hours_weekend' ) ); ?></span>
				</li>
			</ul>
		</div>

		<div class="booking__form">
			<?php echo stail_booking_form( 'main' ); // phpcs:ignore WordPress.Security.EscapeOutput -- escaped inside. ?>
		</div>
	</div>

	<?php if ( stail_opt( 'map_embed' ) ) : ?>
		<div class="container">
			<div class="map" data-src="<?php echo esc_url( stail_opt( 'map_embed' ) ); ?>">
				<button class="map__load" type="button"><?php echo stail_icon( 'pin' ); ?>Показать клинику на карте</button>
			</div>
		</div>
	<?php endif; ?>
</section>
