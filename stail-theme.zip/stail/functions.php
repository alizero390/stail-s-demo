<?php
/**
 * Stail Dental — theme bootstrap.
 *
 * @package stail
 */

defined( 'ABSPATH' ) || exit;

define( 'STAIL_VERSION', '1.1.0' );
define( 'STAIL_DIR', get_template_directory() );
define( 'STAIL_URI', get_template_directory_uri() );

require STAIL_DIR . '/inc/helpers.php';
require STAIL_DIR . '/inc/customizer.php';
require STAIL_DIR . '/inc/post-types.php';
require STAIL_DIR . '/inc/meta-boxes.php';
require STAIL_DIR . '/inc/booking.php';
require STAIL_DIR . '/inc/schema.php';
require STAIL_DIR . '/inc/demo-content.php';
require STAIL_DIR . '/inc/admin.php';

add_action( 'after_setup_theme', function () {
	load_theme_textdomain( 'stail', STAIL_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 260, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'responsive-embeds' );
	add_image_size( 'stail-portrait', 480, 600, true );

	register_nav_menus( array(
		'primary' => __( 'Главное меню', 'stail' ),
		'footer'  => __( 'Меню в подвале', 'stail' ),
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'stail-fonts', STAIL_URI . '/assets/css/fonts.css', array(), STAIL_VERSION );
	wp_enqueue_style( 'stail-main', STAIL_URI . '/assets/css/main.css', array( 'stail-fonts' ), STAIL_VERSION );
	wp_enqueue_script( 'stail-main', STAIL_URI . '/assets/js/main.js', array(), STAIL_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
	wp_enqueue_script( 'stail-booking', STAIL_URI . '/assets/js/booking.js', array(), STAIL_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
} );

/* Preload the main Cyrillic font so headings don't jump on load. */
add_action( 'wp_head', function () {
	echo '<link rel="preload" href="' . esc_url( STAIL_URI . '/assets/fonts/manrope-cyrillic-400-normal.woff2' ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	echo '<link rel="preload" href="' . esc_url( STAIL_URI . '/assets/fonts/cormorant-garamond-cyrillic-600-normal.woff2' ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
}, 1 );

/* Clean up head output that the clinic site does not need. */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'rsd_link' );

add_filter( 'excerpt_length', function () {
	return 24;
} );
add_filter( 'excerpt_more', function () {
	return '…';
} );
