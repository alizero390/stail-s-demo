<?php
/**
 * Not found.
 *
 * @package stail
 */

get_header();
?>
<section class="page-hero page-hero--center">
	<div class="container">
		<h1 class="page-title">Такой страницы нет</h1>
		<p class="page-intro">Возможно, ссылка устарела после обновления сайта. Перейдите на главную или позвоните нам: <a href="<?php echo esc_attr( stail_tel_href() ); ?>"><?php echo esc_html( stail_opt( 'phone' ) ); ?></a>.</p>
		<p><a class="btn btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">На главную</a></p>
	</div>
</section>
<?php
get_footer();
