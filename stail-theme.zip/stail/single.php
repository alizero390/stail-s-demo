<?php
/**
 * Blog post.
 *
 * @package stail
 */

get_header();
while ( have_posts() ) :
	the_post();
	?>
	<article <?php post_class(); ?>>
		<section class="page-hero">
			<div class="container">
				<p class="page-meta"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time></p>
				<h1 class="page-title"><?php the_title(); ?></h1>
			</div>
		</section>
		<section class="section section--tight">
			<div class="container entry">
				<?php if ( has_post_thumbnail() ) : ?>
					<figure class="entry__cover"><?php the_post_thumbnail( 'large' ); ?></figure>
				<?php endif; ?>
				<?php the_content(); ?>
			</div>
		</section>
	</article>
	<?php
endwhile;
get_template_part( 'template-parts/cta' );
get_footer();
