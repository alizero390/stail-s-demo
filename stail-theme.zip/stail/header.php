<?php
/**
 * Site header.
 *
 * @package stail
 */
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#content">Перейти к содержимому</a>

<header class="site-header">
	<div class="container site-header__inner">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php if ( has_custom_logo() ) : ?>
				<?php echo wp_get_attachment_image( get_theme_mod( 'custom_logo' ), 'full', false, array( 'class' => 'brand__logo', 'alt' => stail_opt( 'clinic_name' ) ) ); ?>
			<?php else : ?>
				<span class="brand__mark" aria-hidden="true"><?php echo esc_html( mb_substr( stail_opt( 'clinic_name' ), 0, 1 ) ); ?></span>
				<span class="brand__text">
					<span class="brand__name"><?php echo esc_html( stail_opt( 'clinic_name' ) ); ?></span>
					<span class="brand__since">стоматология с <?php echo esc_html( stail_opt( 'founded' ) ); ?> года</span>
				</span>
			<?php endif; ?>
		</a>

		<nav class="site-nav" id="site-nav" aria-label="Главное меню">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'site-nav__list',
				'fallback_cb'    => false,
				'depth'          => 2,
			) );
			?>
			<div class="site-nav__extra">
				<a class="site-nav__phone" href="<?php echo esc_attr( stail_tel_href() ); ?>"><?php echo esc_html( stail_opt( 'phone' ) ); ?></a>
				<p><?php echo esc_html( stail_opt( 'hours_weekday' ) ); ?><br><?php echo esc_html( stail_opt( 'hours_weekend' ) ); ?></p>
				<a class="btn btn--primary btn--block site-nav__book" href="<?php echo esc_url( home_url( '/#booking' ) ); ?>">Записаться онлайн</a>
			</div>
		</nav>

		<div class="site-header__actions">
			<a class="header-phone" href="<?php echo esc_attr( stail_tel_href() ); ?>">
				<?php echo stail_icon( 'phone' ); ?>
				<span><?php echo esc_html( stail_opt( 'phone' ) ); ?></span>
			</a>
			<a class="btn btn--primary btn--sm header-cta" href="<?php echo esc_url( home_url( '/#booking' ) ); ?>">Записаться</a>
			<button class="nav-toggle" type="button" aria-controls="site-nav" aria-expanded="false">
				<span class="nav-toggle__open"><?php echo stail_icon( 'menu' ); ?></span>
				<span class="nav-toggle__close"><?php echo stail_icon( 'close' ); ?></span>
				<span class="screen-reader-text">Меню</span>
			</button>
		</div>
	</div>
</header>

<main id="content" class="site-main">
